import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Login from "./src/screens/login-signup/login/Login";
import Signup_Email from "./src/screens/login-signup/signup/Signup_Email";
import Signup_Username from "./src/screens/login-signup/signup/Signup_Username";
import Signup_Password from "./src/screens/login-signup/signup/Signup_Password";
import Signup_AccountCreated from "./src/screens/login-signup/signup/Signup_AccountCreated";
import Signup_Verify from "./src/screens/login-signup/signup/Signup_Verify";
import ForgotPassword_Email from "./src/screens/login-signup/forgotpassword/ForgotPassword_Email";
import ForgotPassword_Verification from "./src/screens/login-signup/forgotpassword/ForgotPassword_Verification";
import ForgotPassword_Password from "./src/screens/login-signup/forgotpassword/ForgotPassword_Password";
import ForgotPassword_AccountRecovered from "./src/screens/login-signup/forgotpassword/ForgotPassword_AccountRecovered";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
          animation: "slide_from_right",
        }}
      >
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Signup_Email" component={Signup_Email} />
        <Stack.Screen name="Signup_Verify" component={Signup_Verify} />
        <Stack.Screen name="Signup_Username" component={Signup_Username} />
        <Stack.Screen name="Signup_Password" component={Signup_Password} />
        <Stack.Screen
          name="Signup_AccountCreated"
          component={Signup_AccountCreated}
        />

        <Stack.Screen
          name="ForgotPassword_Email"
          component={ForgotPassword_Email}
        />
        <Stack.Screen
          name="ForgotPassword_Verification"
          component={ForgotPassword_Verification}
        />
        <Stack.Screen
          name="ForgotPassword_Password"
          component={ForgotPassword_Password}
        />
        <Stack.Screen
          name="ForgotPassword_AccountRecovered"
          component={ForgotPassword_AccountRecovered}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
