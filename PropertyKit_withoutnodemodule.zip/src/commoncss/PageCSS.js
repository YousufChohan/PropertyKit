module.exports = {
  containerFull: {
    width: "100%",
    height: "100%",
    backgroundColor: "#FFFF66",
    alignItems: "center",
    justifyConctent: "center",
  },
  logo1: {
    height: "15%",
    resizeMode: "contain",
    marginTop: 200,
    marginBottom: 20,
  },
  hr80: {
    width: "80%",
    height: 1,
    backgroundColor: "#FFFfcc",
    marginVertical: 20,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
  },
};
