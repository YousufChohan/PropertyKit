import { StyleSheet, Text, View } from "react-native";
import React from "react";

const ForgotPassword_Verification = () => {
  return (
    <View>
      <Text>ForgotPassword_Verification</Text>
    </View>
  );
};

export default ForgotPassword_Verification;

const styles = StyleSheet.create({});
