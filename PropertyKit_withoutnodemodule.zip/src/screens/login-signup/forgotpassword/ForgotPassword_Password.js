import { StyleSheet, Text, View } from "react-native";
import React from "react";

const ForgotPassword_Password = () => {
  return (
    <View>
      <Text>ForgotPassword_Password</Text>
    </View>
  );
};

export default ForgotPassword_Password;

const styles = StyleSheet.create({});
