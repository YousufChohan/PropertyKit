import { StyleSheet, Text, View } from "react-native";
import React from "react";

const ForgotPassword_Email = () => {
  return (
    <View>
      <Text>ForgotPassword_Email</Text>
    </View>
  );
};

export default ForgotPassword_Email;

const styles = StyleSheet.create({});
