import { StyleSheet, Text, View } from "react-native";
import React from "react";

const ForgotPassword_AccountRecovered = () => {
  return (
    <View>
      <Text>ForgotPassword_AccountRecovered</Text>
    </View>
  );
};

export default ForgotPassword_AccountRecovered;

const styles = StyleSheet.create({});
