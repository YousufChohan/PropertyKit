import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Signup_AccountCreated = () => {
  return (
    <View>
      <Text>Signup_AccountCreated</Text>
    </View>
  );
};

export default Signup_AccountCreated;

const styles = StyleSheet.create({});
