import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Signup_Password = () => {
  return (
    <View>
      <Text>Signup_Password</Text>
    </View>
  );
};

export default Signup_Password;

const styles = StyleSheet.create({});
