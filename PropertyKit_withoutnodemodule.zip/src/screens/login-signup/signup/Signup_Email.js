import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Signup_Email = () => {
  return (
    <View>
      <Text>Signup_Email</Text>
    </View>
  );
};

export default Signup_Email;

const styles = StyleSheet.create({});
