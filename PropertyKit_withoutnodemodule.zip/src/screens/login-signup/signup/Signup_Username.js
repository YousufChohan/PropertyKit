import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Signup_Username = () => {
  return (
    <View>
      <Text>Signup_Username</Text>
    </View>
  );
};

export default Signup_Username;

const styles = StyleSheet.create({});
