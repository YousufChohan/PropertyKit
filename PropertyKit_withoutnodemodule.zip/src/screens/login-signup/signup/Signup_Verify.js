import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Signup_Verify = () => {
  return (
    <View>
      <Text>Signup_Verify</Text>
    </View>
  );
};

export default Signup_Verify;

const styles = StyleSheet.create({});
