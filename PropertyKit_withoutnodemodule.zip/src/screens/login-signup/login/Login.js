import { StyleSheet, Text, View, Image, TextInput } from "react-native";
import React from "react";
import logo from "../../../../assets/logo.png";
import { NavigationContainer } from "@react-navigation/native";
import { containerFull, logo1 } from "../../../commoncss/PageCSS";
import {
  formButton,
  formHead,
  formInput,
  formTextLinkRight,
} from "../../../commoncss/FormCSS";

const Login = () => {
  return (
    <View style={containerFull}>
      <Image source={logo} style={logo1} />
      <Text style={formHead}>Login</Text>
      <TextInput placeholder="Enter your Email" style={formInput} />
      <TextInput
        placeholder="Enter your Password"
        style={formInput}
        secureTextEntry={true}
      />
      <Text
        style={formTextLinkRight}
        onPress={() => navigation.navigate("ForgotPassword_Email")}
      >
        Forgot Password?
      </Text>
      <Text style={formButton} onPress={() => navigation.navigate("MainPage")}>
        Submit
      </Text>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({});
